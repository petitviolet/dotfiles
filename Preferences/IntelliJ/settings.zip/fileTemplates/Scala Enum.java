sealed abstract class $NAME$(val value: $TYPE$) extends $TYPE$EnumLike
object $NAME$ extends EnumCompanion[$NAME$] {
  case object $FIRST$ extends $NAME$($VALUE$)
  val values = $FIRST$ :: Nil
}